/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
  int a,b,sum;
  printf("enter the first number:");
  scanf("%d",&a);
  printf("enter the second number:");
  scanf("%d",&b);
  sum=a+b;
  printf("sum of two numbers:%d",sum);
    return 0;
}
