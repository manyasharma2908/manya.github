/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
 int l,b,peri,area;
 printf("enter the length of rectangle:");
 scanf("%d",&l);
 printf("enter the berath of rectangle:");
 scanf("%d",&b);
 peri=2*(l+b);
 area=l*b;
 printf("perimeter and area of rectangle:%d,%d",peri,area);

    return 0;
}
